import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DataOutputBuffer;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.util.LineReader;
import org.apache.hadoop.fs.FileSystem;
import java.io.IOException;


public class JsonRecordReader extends RecordReader<LongWritable, Text> {
    private long start;
    private long end;
    private long pos;
    private int maxLineLength;
    private LineReader in;
    private LongWritable key = new LongWritable();
    private final DataOutputBuffer buffer = new DataOutputBuffer();
    private Text value = new Text();
    FSDataInputStream fileIn;
    private byte[] startTag = "{".getBytes();
    private byte[] endTag = "}".getBytes();


    @Override
    public void initialize(InputSplit genericSplit, TaskAttemptContext context) throws IOException{
        FileSplit split = (FileSplit) genericSplit;
        Configuration job = context.getConfiguration();
        this.maxLineLength = job.getInt(
                "mapred.linerecordreader.maxlength",
                Integer.MAX_VALUE);
        start = split.getStart();
        end = start + split.getLength();
        final Path file = split.getPath();
        FileSystem fs = file.getFileSystem(job);

        fileIn = fs.open(split.getPath());
        fileIn.seek(start);
    }
    @Override
    public boolean nextKeyValue() throws IOException {
        // is the end of split?
        if (fileIn.getPos() < end){
            // first we need to find startTag {, so we assign inSameRecord as false;
            if (findTagAndRead(startTag, false)){
                try {
                    buffer.write(startTag);// add bracket for record
                    // since have finded start tag, so the next data is in the same record
                    if (findTagAndRead(endTag, true)){
                        key.set(fileIn.getPos());
                        value.set(buffer.getData(), 0, buffer.getLength());
                        return true;
                    }
                } finally {
                    // release buffer for next record;
                    buffer.reset();
                }
            }
        }
       return false;
    }
    // in same block means is this record is in the same block?
    // if it's not, isJson will continue to find the tag.
    private boolean findTagAndRead(byte[]tag, boolean inSameRecord) throws IOException{
        int i = 0;
        while (true){
            int data =fileIn.read();
            // reach end of file
            if (data == -1)return false;
            if (inSameRecord){
                buffer.write(data);
            }
            // check is data same with tag?
            if (data == tag[i]){
                i++;
                if (i >= tag.length){
                    return true;
                }
            }else i = 0;
            // need to read next split
            if (!inSameRecord && i == 0 && fileIn.getPos() >= end)return false;
        }
    }

    @Override
    public LongWritable getCurrentKey() throws IOException,
            InterruptedException {
        return key;
    }


    @Override
    public Text getCurrentValue() throws IOException, InterruptedException {
        return value;
    }


    @Override
    public float getProgress() throws IOException, InterruptedException {
        if (start == end) {
            return 0.0f;
        } else {
            return Math.min(1.0f, (pos - start) / (float) (end - start));
        }
    }


    @Override
    public void close() throws IOException {
        if (in != null) {
            in.close();
        }
    }
}
